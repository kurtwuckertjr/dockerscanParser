# dockerscanParser 
Prototype parser for Dockerscan reports as a stepping stone to a Dradis integration
